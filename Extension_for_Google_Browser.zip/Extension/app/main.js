import View from "./view/view.js";

const view = new View().run();
