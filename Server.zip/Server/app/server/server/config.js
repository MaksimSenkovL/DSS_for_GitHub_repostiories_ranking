const PORT = 8800;

module.exports = { PORT };
